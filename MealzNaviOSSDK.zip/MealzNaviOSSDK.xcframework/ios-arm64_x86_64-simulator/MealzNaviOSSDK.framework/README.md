# MealzNaviOSSDK

Mealz repo for our Embedded Navigation components.

To build the XCFramework for this project, just set your ENV variables:

`export MEALZ_PROJECT_DIR="/path/to/your/project"`

`export DERIVED_DATA_DIR="/path/to/your/xcode/devrived/data"`

And then run the script:

`sh build_xcframework.sh`

This will create a XCFramework in the /build folder that you can then export (like release with MealzUIiOSSDKRelease).
# MealzNaviOSSDK
