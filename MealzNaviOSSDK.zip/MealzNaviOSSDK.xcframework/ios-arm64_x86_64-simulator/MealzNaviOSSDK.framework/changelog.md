# 1.1.0
[FEA] Add English Localization
[FEA] Localization on Item Selector dynamically updates
[FEA] CTA on MyMeals in MyBasket is now configurable
[FEA] Final Navigation on Meal Planner is now configurable
[FEA] Catalog Results takes preferences setting passed by client
[FEA] Recipe Card now accepts isMealzRecipe for passing in a Recipe Id
[FEA] Catalog Toolbar shows subtitle on categories
[FIX] Fix issue navigating to Preferences Search

# 1.0.0
- Initial Release


