# 1.1.0
[FEA] Add English Localization
[FEA] Localization on Item Selector dynamically updates
[FEA] CTA on MyMeals in MyBasket is now configurable
[FEA] Final Navigation on Meal Planner is now configurable


# 1.0.0
- Initial Release


